import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:pdfx/pdfx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:visibility_detector/visibility_detector.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppStore.instance.init();
  await ReminderService.instance.init();
  runApp(const BhagavatamApp());
}

class AppStore extends ChangeNotifier {
  AppStore._();
  static final instance = AppStore._();

  late SharedPreferences prefs;
  Map<int, List<int>> chapters = {};
  final Map<String, List<Verse>> _cache = {};
  final Set<String> bookmarks = {};
  final Set<String> pdfChapters = {};
  final Map<String, String> notes = {};
  int lastCanto = 1;
  int lastChapter = 1;
  int lastVerse = 1;
  bool dark = false;
  bool reminder = false;
  double fontScale = 1.0;
  String language = 'Sanskrit';

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    dark = prefs.getBool('dark') ?? false;
    reminder = prefs.getBool('reminder') ?? false;
    fontScale = prefs.getDouble('fontScale') ?? 1.0;
    lastCanto = prefs.getInt('lastCanto') ?? 1;
    lastChapter = prefs.getInt('lastChapter') ?? 1;
    lastVerse = prefs.getInt('lastVerse') ?? 1;
    language = prefs.getString('language') ?? 'Sanskrit';
    bookmarks.addAll(prefs.getStringList('bookmarks') ?? []);
    final rawNotes = prefs.getString('notes');
    if (rawNotes != null) {
      try {
        (jsonDecode(rawNotes) as Map<String, dynamic>).forEach((k, v) => notes[k] = '$v');
      } catch (_) {}
    }
    final index = jsonDecode(await rootBundle.loadString('assets/data/index.json')) as Map<String, dynamic>;
    for (final item in index['cantos'] as List) {
      chapters[item['number'] as int] = (item['chapters'] as List).cast<int>();
    }
    pdfChapters.addAll((index['pdfChapters'] as List? ?? []).cast<String>());
  }

  String key(int c, int ch, int v) => '$c-$ch-$v';
  Future<List<Verse>> loadChapter(int c, int ch) async {
    final k = '$c-$ch';
    if (_cache.containsKey(k)) return _cache[k]!;
    try {
      final raw = await rootBundle.loadString('assets/data/chapters/$k.json');
      final list = (jsonDecode(raw) as List).map((e) => Verse.fromJson(e)).toList();
      _cache[k] = list;
      return list;
    } catch (_) {
      return [];
    }
  }

  Future<void> setLast(int c, int ch, int v) async {
    if (lastCanto == c && lastChapter == ch && lastVerse == v) return;
    lastCanto = c; lastChapter = ch; lastVerse = v;
    await prefs.setInt('lastCanto', c);
    await prefs.setInt('lastChapter', ch);
    await prefs.setInt('lastVerse', v);
    notifyListeners();
  }

  Future<void> toggleBookmark(String id) async {
    if (!bookmarks.add(id)) bookmarks.remove(id);
    await prefs.setStringList('bookmarks', bookmarks.toList());
    notifyListeners();
  }

  Future<void> saveNote(String id, String value) async {
    if (value.trim().isEmpty) {
      notes.remove(id);
    } else {
      notes[id] = value.trim();
    }
    await prefs.setString('notes', jsonEncode(notes));
    notifyListeners();
  }

  Future<void> setDark(bool value) async {
    dark = value; await prefs.setBool('dark', value); notifyListeners();
  }
  Future<void> setReminder(bool value) async {
    reminder = value; await prefs.setBool('reminder', value);
    if (value) {
      await ReminderService.instance.scheduleDaily();
    } else {
      await ReminderService.instance.cancel();
    }
    notifyListeners();
  }
  Future<void> setFont(double value) async {
    fontScale = value; await prefs.setDouble('fontScale', value); notifyListeners();
  }
  Future<void> setLanguage(String value) async {
    language = value; await prefs.setString('language', value); notifyListeners();
  }
}

class Verse {
  final int number;
  final String text;
  Verse(this.number, this.text);
  factory Verse.fromJson(Map<String, dynamic> j) => Verse(j['verse_number'] as int, (j['verse_text'] ?? '').toString());
}

class ReminderService {
  ReminderService._();
  static final instance = ReminderService._();
  final plugin = FlutterLocalNotificationsPlugin();
  Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await plugin.initialize(const InitializationSettings(android: android));
  }
  Future<void> scheduleDaily() async {
    final android = plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'daily_verse', 'Daily verse',
        channelDescription: 'A gentle reminder to read the Srimad Bhagavatam',
        importance: Importance.defaultImportance,
        priority: Priority.defaultPriority,
      ),
    );
    await plugin.periodicallyShow(
      1001, 'Your daily Bhagavatam reading',
      'Take a quiet moment for today’s verse.',
      RepeatInterval.daily, details,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }
  Future<void> cancel() => plugin.cancel(1001);
}

class BhagavatamApp extends StatelessWidget {
  const BhagavatamApp({super.key});
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppStore.instance,
      builder: (context, _) {
        final dark = AppStore.instance.dark;
        const cream = Color(0xFFF7F1E5);
        const ink = Color(0xFF292923);
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Srimad Bhagavatam',
          theme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.light,
            scaffoldBackgroundColor: cream,
            colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF9A6A32), brightness: Brightness.light),
            appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: ink, elevation: 0),
            cardTheme: CardThemeData(color: const Color(0xFFFFFCF6), elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
            fontFamily: 'LohitDevanagari',
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.dark,
            scaffoldBackgroundColor: const Color(0xFF171A1D),
            colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFC49A63), brightness: Brightness.dark),
            cardTheme: CardThemeData(color: const Color(0xFF22272B), elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
            fontFamily: 'LohitDevanagari',
          ),
          themeMode: dark ? ThemeMode.dark : ThemeMode.light,
          home: const HomeScreen(),
        );
      },
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  final pages = const [DashboardPage(), BrowsePage(), SearchPage(), BookmarksPage(), SettingsPage()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.spa_outlined), selectedIcon: Icon(Icons.spa), label: 'Today'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Read'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.bookmark_outline), selectedIcon: Icon(Icons.bookmark), label: 'Saved'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Settings'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return AnimatedBuilder(
      animation: s,
      builder: (context, _) => CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 24, 22, 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('HARE KRISHNA', style: Theme.of(context).textTheme.labelMedium?.copyWith(letterSpacing: 2, color: Theme.of(context).colorScheme.primary)),
              const SizedBox(height: 10),
              Text('Srimad Bhagavatam', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text('A quiet space for daily study and reflection', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).hintColor)),
              const SizedBox(height: 24),
              _DailyCard(),
              const SizedBox(height: 16),
              Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('CONTINUE READING', style: Theme.of(context).textTheme.labelSmall?.copyWith(letterSpacing: 1.5, color: Theme.of(context).colorScheme.primary)),
                const SizedBox(height: 8),
                Text('Canto ${s.lastCanto}  ·  Chapter ${s.lastChapter}  ·  Verse ${s.lastVerse}', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReaderPage(canto: s.lastCanto, chapter: s.lastChapter, initialVerse: s.lastVerse))), icon: const Icon(Icons.play_arrow), label: const Text('Continue reading')),
              ]))),
              const SizedBox(height: 18),
              Text('YOUR STUDY', style: Theme.of(context).textTheme.labelSmall?.copyWith(letterSpacing: 1.5, color: Theme.of(context).colorScheme.primary)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _StatCard(icon: Icons.bookmark, label: 'Bookmarks', value: '${s.bookmarks.length}')),
                const SizedBox(width: 10),
                Expanded(child: _StatCard(icon: Icons.edit_note, label: 'Study notes', value: '${s.notes.length}')),
              ]),
              const SizedBox(height: 28),
            ]),
          )),
        ],
      ),
    );
  }
}

class _DailyCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return FutureBuilder<List<Verse>>(
      future: s.loadChapter(1, 1),
      builder: (context, snap) {
        final verses = snap.data ?? [];
        final verse = verses.isEmpty ? null : verses[DateTime.now().day % verses.length];
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: Theme.of(context).brightness == Brightness.dark
              ? [const Color(0xFF34352E), const Color(0xFF252B2B)]
              : [const Color(0xFFEDE0C8), const Color(0xFFF8EEDF)]),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Icon(Icons.wb_sunny_outlined, size: 18), const SizedBox(width: 8), Text('VERSE OF THE DAY', style: Theme.of(context).textTheme.labelSmall?.copyWith(letterSpacing: 1.4))]),
            const SizedBox(height: 16),
            if (verse == null) const CircularProgressIndicator() else Text(verse.text, maxLines: 7, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium?.copyWith(height: 1.9, fontSize: 17 * s.fontScale)),
            const SizedBox(height: 12),
            Text('Śrīmad Bhāgavatam · 1.1.${verse?.number ?? 1}', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 14),
            Row(children: [
              OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReaderPage(canto: 1, chapter: 1, initialVerse: verse?.number ?? 1))), icon: const Icon(Icons.menu_book, size: 16), label: const Text('Read verse')),
              const Spacer(),
              IconButton(onPressed: () => s.setReminder(!s.reminder), icon: Icon(s.reminder ? Icons.notifications_active : Icons.notifications_none), tooltip: 'Daily reminder'),
            ]),
          ]),
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon; final String label; final String value;
  const _StatCard({required this.icon, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
    Icon(icon, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: Theme.of(context).textTheme.titleLarge), Text(label, style: Theme.of(context).textTheme.bodySmall)])),
  ])));
}

class BrowsePage extends StatelessWidget {
  const BrowsePage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('Browse the Bhagavatam')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
        Text('Twelve cantos · Choose a canto to explore its chapters', style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 16),
        ...s.chapters.entries.map((entry) => Card(
          child: ExpansionTile(
            leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: Text('${entry.key}')),
            title: Text('Canto ${entry.key}', style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text('${entry.value.length} chapters'),
            children: entry.value.map((ch) => ListTile(
              title: Text('Chapter $ch'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReaderPage(canto: entry.key, chapter: ch))),
            )).toList(),
          ),
        )),
      ]),
    );
  }
}

class ReaderPage extends StatefulWidget {
  final int canto, chapter, initialVerse;
  const ReaderPage({super.key, required this.canto, required this.chapter, this.initialVerse = 1});
  @override
  State<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends State<ReaderPage> {
  late Future<List<Verse>> future;
  final tts = FlutterTts();
  bool speaking = false;
  double speechRate = 0.42;
  String tab = 'Sanskrit';
  @override
  void initState() {
    super.initState();
    future = AppStore.instance.loadChapter(widget.canto, widget.chapter);
    AppStore.instance.setLast(widget.canto, widget.chapter, widget.initialVerse);
    tts.setCompletionHandler(() { if (mounted) setState(() => speaking = false); });
  }
  @override
  void dispose() { tts.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return Scaffold(
      appBar: AppBar(title: Text('Canto ${widget.canto} · Chapter ${widget.chapter}')),
      body: FutureBuilder<List<Verse>>(
        future: future,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final verses = snap.data!;
          if (verses.isEmpty) return const Center(child: Text('This chapter text is not available.'));
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
            children: [
              Wrap(spacing: 8, runSpacing: 8, children: [
                _languageChip('Sanskrit'), _languageChip('English'), _languageChip('Hindi'), _languageChip('Gujarati'), _languageChip('Purport'),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: Text('${verses.length} verses', style: Theme.of(context).textTheme.bodySmall)),
                PopupMenuButton<double>(tooltip: 'Audio speed', onSelected: (v) { setState(() => speechRate = v); tts.setSpeechRate(v); }, itemBuilder: (_) => const [PopupMenuItem(value: .32, child: Text('0.75× audio')), PopupMenuItem(value: .42, child: Text('1× audio')), PopupMenuItem(value: .52, child: Text('1.25× audio')), PopupMenuItem(value: .62, child: Text('1.5× audio'))], child: const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Icon(Icons.speed))),
                IconButton(onPressed: () => s.setFont((s.fontScale - .1).clamp(.8, 1.6)), icon: const Icon(Icons.text_decrease)),
                Text('${(s.fontScale * 100).round()}%', style: Theme.of(context).textTheme.labelSmall),
                IconButton(onPressed: () => s.setFont((s.fontScale + .1).clamp(.8, 1.6)), icon: const Icon(Icons.text_increase)),
              ]),
              ...verses.map((v) => _verseCard(v)),
              const SizedBox(height: 12),
              if (s.pdfChapters.contains('${widget.canto}-${widget.chapter}'))
                FilledButton.tonalIcon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderPage(canto: widget.canto, chapter: widget.chapter))),
                  icon: const Icon(Icons.picture_as_pdf), label: const Text('Open offline chapter reference PDF'),
                ),
            ],
          );
        },
      ),
    );
  }

  Widget _languageChip(String label) => ChoiceChip(label: Text(label), selected: tab == label, onSelected: (_) => setState(() => tab = label));
  Widget _verseCard(Verse v) {
    final s = AppStore.instance;
    final id = s.key(widget.canto, widget.chapter, v.number);
    final isSanskrit = tab == 'Sanskrit';
    final available = tab == 'Sanskrit';
    return VisibilityDetector(
      key: Key('verse-visible-$id'),
      onVisibilityChanged: (info) { if (info.visibleFraction > 0.55) s.setLast(widget.canto, widget.chapter, v.number); },
      child: Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text('VERSE ${v.number}', style: Theme.of(context).textTheme.labelSmall?.copyWith(letterSpacing: 1.2, color: Theme.of(context).colorScheme.primary)),
          const Spacer(),
          IconButton(visualDensity: VisualDensity.compact, onPressed: () => s.toggleBookmark(id), icon: Icon(s.bookmarks.contains(id) ? Icons.bookmark : Icons.bookmark_border)),
          IconButton(visualDensity: VisualDensity.compact, onPressed: () => _editNote(id), icon: Icon(s.notes.containsKey(id) ? Icons.edit_note : Icons.note_add_outlined)),
        ]),
        const SizedBox(height: 10),
        if (available)
          SelectableText(v.text, textAlign: TextAlign.center, style: TextStyle(fontFamily: 'LohitDevanagari', fontSize: 19 * s.fontScale, height: 2.0))
        else
          _missingContent(tab),
        const SizedBox(height: 10),
        Row(children: [
          Text('SB ${widget.canto}.${widget.chapter}.${v.number}', style: Theme.of(context).textTheme.bodySmall),
          const Spacer(),
          IconButton(onPressed: () => _speak(v.text), icon: Icon(speaking ? Icons.stop_circle_outlined : Icons.volume_up_outlined)),
        ]),
        if (s.notes.containsKey(id)) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Note: ${s.notes[id]}', style: Theme.of(context).textTheme.bodySmall)),
      ])),
      ),
    );
  }

  Widget _missingContent(String section) => Container(
    width: double.infinity, padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(12)),
    child: Text(
      section == 'Hindi' ? 'Hindi translation and purport are available in the bundled chapter reference PDF where present. Open the PDF below.' :
      '$section text is not included in the uploaded APK’s structured data. It has been left blank rather than generating an unverified translation.',
      style: Theme.of(context).textTheme.bodyMedium,
    ),
  );

  Future<void> _speak(String text) async {
    if (speaking) { await tts.stop(); setState(() => speaking = false); return; }
    await tts.setLanguage('hi-IN');
    await tts.setSpeechRate(speechRate);
    await tts.speak(text);
    setState(() => speaking = true);
  }

  Future<void> _editNote(String id) async {
    final controller = TextEditingController(text: AppStore.instance.notes[id] ?? '');
    final result = await showDialog<String>(context: context, builder: (context) => AlertDialog(
      title: const Text('Study note'),
      content: TextField(controller: controller, maxLines: 5, decoration: const InputDecoration(hintText: 'Write your reflection or study note…')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Save')),
      ],
    ));
    if (result != null) await AppStore.instance.saveNote(id, result);
    if (mounted) setState(() {});
  }
}


class PdfReaderPage extends StatefulWidget {
  final int canto, chapter;
  const PdfReaderPage({super.key, required this.canto, required this.chapter});
  @override
  State<PdfReaderPage> createState() => _PdfReaderPageState();
}
class _PdfReaderPageState extends State<PdfReaderPage> {
  PdfControllerPinch? controller;
  String? error;
  @override
  void initState() {
    super.initState();
    final path = 'assets/data/pdf/${widget.canto}/${widget.chapter}.pdf';
    rootBundle.load(path).then((data) async {
      final doc = await PdfDocument.openData(data.buffer.asUint8List());
      if (mounted) setState(() => controller = PdfControllerPinch(document: Future.value(doc)));
    }).catchError((_) { if (mounted) setState(() => error = 'No reference PDF is bundled for this chapter.'); });
  }
  @override
  void dispose() { controller?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Chapter ${widget.chapter} · PDF reference')),
    body: error != null ? Center(child: Text(error!)) : controller == null
      ? const Center(child: CircularProgressIndicator())
      : PdfViewPinch(controller: controller!),
  );
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  final controller = TextEditingController();
  List<_SearchHit> hits = [];
  bool busy = false;
  Future<void> search(String q) async {
    if (q.trim().isEmpty) { setState(() => hits = []); return; }
    setState(() => busy = true);
    final s = AppStore.instance;
    final found = <_SearchHit>[];
    for (final entry in s.chapters.entries) {
      for (final ch in entry.value) {
        final verses = await s.loadChapter(entry.key, ch);
        for (final v in verses) {
          if (v.text.toLowerCase().contains(q.toLowerCase())) {
            found.add(_SearchHit(entry.key, ch, v));
            if (found.length >= 150) break;
          }
        }
        if (found.length >= 150) break;
      }
      if (found.length >= 150) break;
    }
    if (mounted) setState(() { hits = found; busy = false; });
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Search the text')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(16), child: TextField(
        controller: controller, onSubmitted: search,
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Search Sanskrit words or phrases', suffixIcon: IconButton(icon: const Icon(Icons.clear), onPressed: () { controller.clear(); search(''); }), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
      )),
      if (busy) const LinearProgressIndicator(),
      Expanded(child: hits.isEmpty ? Center(child: Text(controller.text.isEmpty ? 'Search across all available Sanskrit verses' : 'No matching verses found', style: Theme.of(context).textTheme.bodyMedium)) : ListView.builder(
        itemCount: hits.length, itemBuilder: (context, i) {
          final h = hits[i];
          return ListTile(
            title: Text('SB ${h.canto}.${h.chapter}.${h.verse.number}'),
            subtitle: Text(h.verse.text, maxLines: 2, overflow: TextOverflow.ellipsis),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReaderPage(canto: h.canto, chapter: h.chapter, initialVerse: h.verse.number))),
          );
        },
      )),
    ]),
  );
}
class _SearchHit { final int canto, chapter; final Verse verse; _SearchHit(this.canto, this.chapter, this.verse); }

class BookmarksPage extends StatelessWidget {
  const BookmarksPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return AnimatedBuilder(
      animation: s,
      builder: (context, _) {
        final keys = s.bookmarks.toList()..sort();
        return Scaffold(
          appBar: AppBar(title: const Text('Saved verses')),
          body: keys.isEmpty ? const Center(child: Text('Your bookmarked verses will appear here.')) : ListView(
            children: keys.map((id) {
              final p = id.split('-').map(int.parse).toList();
              return ListTile(
                leading: const Icon(Icons.bookmark),
                title: Text('SB ${p[0]}.${p[1]}.${p[2]}'),
                subtitle: Text(s.notes[id] ?? 'Bookmarked verse'),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReaderPage(canto: p[0], chapter: p[1], initialVerse: p[2]))),
              );
            }).toList(),
          ),
        );
      },
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return AnimatedBuilder(
      animation: s,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Reading settings')),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          SwitchListTile(title: const Text('Night reading mode'), subtitle: const Text('Use a calm dark background'), value: s.dark, onChanged: s.setDark),
          SwitchListTile(title: const Text('Daily verse reminder'), subtitle: const Text('A daily notification on this device'), value: s.reminder, onChanged: s.setReminder),
          const SizedBox(height: 18),
          Text('Text size', style: Theme.of(context).textTheme.titleMedium),
          Slider(value: s.fontScale, min: .8, max: 1.6, divisions: 8, label: '${(s.fontScale * 100).round()}%', onChanged: s.setFont),
          const SizedBox(height: 18),
          Text('Available content', style: Theme.of(context).textTheme.titleMedium),
          const ListTile(leading: Icon(Icons.offline_pin), title: Text('Offline Sanskrit verses'), subtitle: Text('348 chapter files · 14,402 verse records')),
          const ListTile(leading: Icon(Icons.picture_as_pdf), title: Text('Offline Hindi reference PDFs'), subtitle: Text('335 chapter PDF files, where available')),
          const ListTile(leading: Icon(Icons.info_outline), title: Text('Translation coverage'), subtitle: Text('Structured English and Gujarati translations, transliteration and word meanings were not present in the supplied APK data.')),
          const SizedBox(height: 18),
          Text('About', style: Theme.of(context).textTheme.titleMedium),
          const ListTile(leading: Icon(Icons.auto_awesome), title: Text('Srimad Bhagavatam Reader'), subtitle: Text('A personal offline study companion. Audio uses voices installed on your Android device.')),
        ]),
      ),
    );
  }
}
