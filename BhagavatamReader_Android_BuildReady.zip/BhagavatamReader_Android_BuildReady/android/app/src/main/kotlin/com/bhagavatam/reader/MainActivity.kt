package com.bhagavatam.reader

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
