# Srimad Bhagavatam Reader — Android source project

This is a fresh Flutter source project prepared from the resources in the APK uploaded by the user. It is designed for offline reading and cloud APK builds through GitHub Actions.

## What is included

- 335 canonical chapter JSON files containing 14,044 Sanskrit verse records, plus 13 alternate/original JSON variants (348 JSON files total).
- 335 offline chapter PDF reference files extracted from the uploaded APK.
- Devanagari font files from the uploaded APK.
- Canto/chapter navigation, verse reading, search, bookmarks, notes, last-read progress, light/dark theme, font scaling and text-to-speech.
- Hindi reference PDFs can be opened offline from the chapter reader.

## Important content limitation

The structured JSON data in the uploaded APK has only `verse_number` and `verse_text`. It does **not** contain structured English/Gujarati translations, Roman transliteration, word-for-word meanings, or structured purports. The bundled PDFs are offline chapter reference scans (their extracted text uses a legacy Hindi font encoding). This app does not fabricate missing scripture translations or commentary. English/Gujarati/purport fields are presented as clearly marked unavailable until verified source text is supplied.

## Build APK in GitHub Actions (mobile-friendly)

1. Create a GitHub account and a new repository.
2. Upload the **contents** of this ZIP to the repository (not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and press **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, scroll to **Artifacts**, and download `BhagavatamReader-debug-apk`.
7. Extract the downloaded artifact ZIP and install the APK on your Android phone. If Android asks, allow installation from that source.

The workflow generates the Android Gradle wrapper, then builds a debug APK, which is suitable for personal testing. A Play Store release requires a separately configured signing key.

## Local build

Install Flutter stable and Android SDK, then run:

```bash
flutter pub get
flutter build apk --debug
```

Output: `build/app/outputs/flutter-apk/app-debug.apk`

## Project layout

- `lib/main.dart` — application UI and local functionality
- `assets/data/chapters/` — Sanskrit verse JSON
- `assets/data/pdf/` — offline Hindi reference PDFs
- `assets/fonts/` — supplied Devanagari fonts
- `.github/workflows/build-apk.yml` — cloud APK build workflow

## Notes

- Audio uses Android's installed text-to-speech voices. Voice availability depends on the device.
- Daily reminder uses Android notifications; Android 13+ may ask for notification permission.
- User bookmarks, notes, theme, font size, reminder preference and last-read location are stored locally on the device.
